# Sentiment-Analysis-NLTK-ML and LSTM
Sentiment Analysis on the First Republic Party debate in 2016 based on Python,NLTK and ML | LSTM.

- Sentiment.ipynb contains ML implementation of the problem
- LSTM.ipynb contains a Recurrant Neural Network implementation of the problem
